C:\MSTGen\exampleFiles\MSTR1-3-3_MI.MGS
C:\MSTGen\exampleFiles\MSTS6.MGS